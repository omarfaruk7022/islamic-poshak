import React from 'react';

export default function OrderConfirmation () {
    return (
        <div>
        <h2>Order confirmation</h2>
        </div>
    );
};
