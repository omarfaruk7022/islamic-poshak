import React from 'react';

export default function CartItem () {
    return (
        <div>
        <h2>Cart item </h2>
        </div>
    );
};
