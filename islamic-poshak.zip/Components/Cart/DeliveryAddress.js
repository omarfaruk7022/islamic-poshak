import React from 'react';

export default function DeliveryAddress () {
    return (
        <div>
        <h2>Delivery address</h2>
        </div>
    );
};
