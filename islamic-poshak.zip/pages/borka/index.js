import Borka from "@/Components/Home/Borka";
import Hijab from "@/Components/Home/Hijab";
import Navbar from "@/Components/Home/Navbar";
import React, { useState } from "react";

export default function borka() {
  return (
    <div>
      <Navbar />
      <Borka />
    </div>
  );
}
