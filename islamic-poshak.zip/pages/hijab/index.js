import Hijab from "@/Components/Home/Hijab";
import Navbar from "@/Components/Home/Navbar";
import React, { useState } from "react";

export default function hijab() {
  return (
    <div>
      <Navbar />
      <Hijab />
    </div>
  );
}
